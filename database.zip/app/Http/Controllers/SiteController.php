<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class SiteController extends Controller
{
    public function login()
    {
        return view('login');
    }


    public function createBranch()
    {
        return view('createBranch');
    }
    public function createcategory()
    {
        return view('createcategory');
    }
    public function createholiday()
    {
        return view('createholiday');
    }
    public function LeaveEntitlement()
    {
        return view('LeaveEntitlement');
    }
    public function weeklyholiday()
    {
        return view('weeklyholiday');
    }
    public function createshift()
    {
        return view('createshift');
    }
    public function workorder()
    {
        return view('workorder');
    }
    public function location()
    {
        return view('location');
    }
    public function loanmaster()
    {
        return view('loanmaster');
    }
    public function leavetype()
    {
        return view('leavetype');
    }
    public function skillwages()
    {
        return view('skillwages');
    }
    public function bankdetails()
    {
        return view('bankdetails');
    }
    public function fieldcreation()
    {
        return view('fieldcreation');
    }
    public function formula()
    {
        return view('formula');
    }
    public function contractlabour()
    {
        return view('contractlabour');
    }
    public function contractor()
    {
        return view('contractor');
    }
    public function employee()
    {
        return view('employee');
    }
    public function incometaxsettings()
    {
        return view('incometaxsettings');
    }
    public function pfpercentagecalc()
    {
        return view('pfpercentagecalc');
    }
    public function attendance()
    {
        return view('attendance');
    }

    public function esipercentagecalc()
    {
        return view('esipercentagecalc');
    }
    public function professionalslabs()
    {
        return view('professionalslabs');
    }
    public function lwfconfiguration()
    {
        return view('lwfconfiguration');
    }
    public function revisionconfiguration()
    {
        return view('revisionconfiguration');
    }
    public function workhours()
    {
        return view('workhours');
    }
    public function licmatching()
    {
        return view('licmatching');
    }
    public function notation()
    {
        return view('notation');
    }

    public function loanreverseforeclose()
    {
        return view('loanreverseforeclose');
    }
    public function loanforeclose()
    {
        return view('loanforeclose');
    }
    public function incomechallanentry()
    {
        return view('incomechallanentry');
    }

    public function payrollprocess()
    {
        return view('payrollprocess');
    }
    public function ffsettlement()
    {
        return view('ffsettlement');
    }
    public function incometaxprocess()
    {
        return view('incometaxprocess');
    }
    public function pfextract()
    {
        return view('pfextract');
    }
    public function pfonlineextractecr()
    {
        return view('pfonline_extract_ecr');
    }
    public function esiextract()
    {
        return view('esiextract');
    }
    public function professionaltaxstatement()
    {
        return view('professionaltaxstatement');
    }
    public function labourwelfarefundstatement()
    {
        return view('labourwelfarefundstatement');
    }
    public function wageslip()
    {
        return view('wageslip');
    }
    public function wageslipmail()
    {
        return view('wageslipmail');
    }
    public function form16ofemployeelist()
    {
        return view('form16ofemployeelist');
    }
    public function form16mail()
    {
        return view('form16mail');
    }
    public function incometaxannualstatement()
    {
        return view('incometaxannualstatement');
    }
    public function register()
    {
        return view('register');
    }

    public function allocate_rights()
    {
        return view('allocate_rights');
    }

    public function attendance_consolidation()
    {
        return view('attendance_consolidation');
    }

    public function attendance_upload()
    {
        return view('attendance_upload');
    }

    public function capture_monthly_input()
    {
        return view('capture_monthly_input');
    }

    public function employee_transfer()
    {
        return view('employee_transfer');
    }

    public function income_matching()
    {
        return view('income_matching');
    }

    public function income_tax_declaration_entry_upload()
    {
        return view('income_tax_declaration_entry_upload');
    }


    public function income_tax_process()
    {
        return view('income_tax_process');
    }

    public function loan_deviation()
    {
        return view('loan_deviation');
    }

    public function payroll_process()
    {
        return view('payroll_process');
    }


    public function revision_entry()
    {
        return view('revision_entry');
    }

    public function section_matching()
    {
        return view('section_matching');
    }

    public function full_final_settlement()
    {
        return view('full_final_settlement');
    }



    public function addition_of_separation_report()
    {
        return view('addition_of_separation_report');
    }

    public function arrear_statement()
    {
        return view('arrear_statement');
    }

    public function attendance_report()
    {
        return view('attendance_report');
    }

    public function deduction_summary()
    {
        return view('deduction_summary');
    }

    public function earnings_summary()
    {
        return view('earnings_summary');
    }

    public function loan_statement()
    {
        return view('loan_statement');
    }

    public function wagesummary()
    {
        return view('wagesummary');
    }

    public function return()
    {
        return view('return');
    }

    public function usercreation()
    {
        return view('usercreation');
    }

    public function form24Q_income_tax()
    {
        return view('form24Q_income_tax');
    }

    public function income_tax_statement()
    {
        return view('income_tax_statement');
    }

    public function form24QA_income_tax()
    {
        return view('form24QA_income_tax');
    }

    public function income_tax_worksheet()
    {
        return view('income_tax_worksheet');
    }

    public function worksheet_mail()
    {
        return view('worksheet_mail');
    }

    public function roles_creation()
    {
        return view('roles_creation');
    }

    public function offline_payment_entry()
    {
        return view('offline_payment_entry');
    }

    public function excel_wizard()
    {
        return view('excel_wizard');
    }

    public function over_time()
    {
        return view('overtime_entry');
    }

    public function work_order_report()
    {
        return view('work_order_report');
    }


    //company
    public function createcompany()
    {
        return view('dashboard'); // Your blade file
    }
    public function companyStore(Request $request)
    {
        // Validation rules
        $request->validate([
            // Required basic fields
            'company_name' => 'required|string|max:255',
            'company_short_name' => 'required|string|max:100',
            'reference_no' => 'required|string|max:100',
            'state' => 'required|string|max:100',
            'city' => 'required|string|max:100',
            'pincode' => 'required|string|max:20',
            'contact_person' => 'required|string|max:150',
            'mobile_number' => 'required|string|max:20',
            'email' => 'required|email|max:150|unique:companies,email',
            'agreement_type' => 'required|in:company,legal',

            // Optional fields
            'address1' => 'nullable|string',
            'address2' => 'nullable|string',
            'telephone_number' => 'nullable|string|max:20',
            'companyurl' => 'nullable|url|max:255',
            'company_logo' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',

            // Registration arrays
            'registration_type.*' => 'nullable|string|max:100',
            'registration_no.*' => 'nullable|string|max:150',
            'registration_attachment.*' => 'nullable|file|mimes:jpeg,png,jpg,pdf|max:5120',

            // Agreement fields (required only if type is 'company')
            'agreement_ref_no' => 'nullable|string|max:150',
            'agreement_name' => 'nullable|string|max:255',
            'nature_of_agreement' => 'nullable|string|max:150',
            'mode_of_document' => 'nullable|string|max:150',
            'no_of_legalentity' => 'nullable|integer',
            'agreement_date' => 'nullable|date',
            'agreement_type_dropdown' => 'nullable|string|max:150',
            'vertical' => 'nullable|string|max:150',
            'effective_from' => 'nullable|date',
            'effective_to' => 'nullable|date|after_or_equal:effective_from',
            'renewal_due_on' => 'nullable|date',

            // Scope fields
            'domain_name' => 'nullable|string|max:150',
            'type_of_organization' => 'nullable|string|max:150',
            'scope_state' => 'nullable|string|max:100',
            'act' => 'nullable|string|max:150',

            // Status
            'status' => 'required|in:Draft,Saved',
        ]);

        $companyId = null;
        $tenantDbName = null;
        $companyFolder = null;

        try {
            // Generate company ID
            $lastCompany = DB::table('companies')->orderByDesc('id')->first();
            $nextNumber = $lastCompany && preg_match('/company_(\d+)/', $lastCompany->company_id ?? '', $matches)
                ? (int)$matches[1] + 1
                : 1;
            $companyId = 'company_' . str_pad($nextNumber, 3, '0', STR_PAD_LEFT);

            // Generate tenant database name
            $companyName = trim($request->company_name);
            $tenantDbName = 'tenant_' . strtolower(preg_replace('/[^a-zA-Z0-9]+/', '_', $companyName));
            $tenantDbName = trim($tenantDbName, '_');
            $tenantDbName = preg_replace('/_+/', '_', $tenantDbName);

            // Check if database already exists
            $dbExists = DB::select("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?", [$tenantDbName]);
            if (!empty($dbExists)) {
                return back()->with('error', 'A company with similar name already exists!')->withInput();
            }

            // Create company folder structure
            $companyFolder = public_path("assets/company/{$companyId}");
            if (!file_exists($companyFolder)) {
                mkdir($companyFolder, 0755, true);
                mkdir($companyFolder . '/registrations', 0755, true);
            }

            // Handle company logo upload
            $logoPath = null;
            if ($request->hasFile('company_logo')) {
                $logoFile = $request->file('company_logo');
                $logoName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $logoFile->getClientOriginalName());
                $logoFile->move($companyFolder, $logoName);
                $logoPath = "assets/company/{$companyId}/{$logoName}";
            }

            // Handle multiple registration attachments
            $registrationTypes = [];
            $registrationNumbers = [];
            $registrationAttachments = [];

            if ($request->has('registration_type')) {
                foreach ($request->registration_type as $index => $type) {
                    if (!empty($type)) {
                        $registrationTypes[] = $type;
                        $registrationNumbers[] = $request->registration_no[$index] ?? null;

                        // Handle attachment for this registration
                        $attachmentPath = null;
                        if ($request->hasFile("registration_attachment.{$index}")) {
                            $file = $request->file("registration_attachment.{$index}");
                            $fileName = time() . "_{$index}_" . preg_replace('/[^a-zA-Z0-9._-]/', '', $file->getClientOriginalName());
                            $file->move($companyFolder . '/registrations', $fileName);
                            $attachmentPath = "assets/company/{$companyId}/registrations/{$fileName}";
                        }
                        $registrationAttachments[] = $attachmentPath;
                    }
                }
            }

            // Prepare data for main database (hr_payroll)
            $companyData = [
                'company_id' => $companyId,
                'type' => $request->agreement_type,
                'db_name' => $tenantDbName,
                'company_name' => $companyName,
                'company_short_name' => $request->company_short_name,
                'reference_no' => $request->reference_no,
                'address1' => $request->address1,
                'address2' => $request->address2,
                'state' => $request->state,
                'city' => $request->city,
                'pincode' => $request->pincode,
                'contact_person' => $request->contact_person,
                'mobile_number' => $request->mobile_number,
                'telephone_number' => $request->telephone_number,
                'email' => $request->email,
                'companyurl' => $request->companyurl,
                'company_logo' => $logoPath,
                'registration_type' => !empty($registrationTypes) ? json_encode($registrationTypes) : null,
                'registration_no' => !empty($registrationNumbers) ? json_encode($registrationNumbers) : null,
                'registration_attachment' => !empty($registrationAttachments) ? json_encode($registrationAttachments) : null,
                'status' => $request->status,
                'added_by' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ];

            // Add agreement and scope fields only if type is 'company'
            if ($request->agreement_type === 'company') {
                $companyData['agreement_ref_no'] = $request->agreement_ref_no;
                $companyData['agreement_name'] = $request->agreement_name;
                $companyData['nature_of_agreement'] = $request->nature_of_agreement;
                $companyData['mode_of_document'] = $request->mode_of_document;
                $companyData['no_of_legalentity'] = $request->no_of_legalentity;
                $companyData['agreement_date'] = $request->agreement_date;
                $companyData['agreement_type'] = $request->agreement_type_dropdown;
                $companyData['vertical'] = $request->vertical;
                $companyData['effective_from'] = $request->effective_from;
                $companyData['effective_to'] = $request->effective_to;
                $companyData['renewal_due_on'] = $request->renewal_due_on;
                $companyData['domain_name'] = $request->domain_name;
                $companyData['type_of_organization'] = $request->type_of_organization;
                $companyData['scope_state'] = $request->scope_state;
                $companyData['act'] = $request->act;
            }

            // Insert into main database companies table
            DB::table('companies')->insert($companyData);

            // Create tenant database
            DB::statement("CREATE DATABASE IF NOT EXISTS `{$tenantDbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

            // Verify database creation
            $dbCreated = DB::select("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?", [$tenantDbName]);
            if (empty($dbCreated)) {
                throw new \Exception("Failed to create tenant database: {$tenantDbName}");
            }

            // Configure tenant database connection
            config(['database.connections.tenant.database' => $tenantDbName]);
            DB::purge('tenant');
            DB::connection('tenant')->reconnect();

            // Run migrations on tenant database
            Artisan::call('migrate', [
                '--database' => 'tenant',
                '--path' => 'database/migrations/tenant',
                '--force' => true,
            ]);

            // Prepare data for tenant database
            $tenantCompanyData = [
                'company_id' => $companyId,
                'type' => $request->agreement_type,
                'company_name' => $companyName,
                'company_short_name' => $request->company_short_name,
                'reference_no' => $request->reference_no,
                'address1' => $request->address1,
                'address2' => $request->address2,
                'state' => $request->state,
                'city' => $request->city,
                'pincode' => $request->pincode,
                'contact_person' => $request->contact_person,
                'mobile_number' => $request->mobile_number,
                'telephone_number' => $request->telephone_number,
                'email' => $request->email,
                'companyurl' => $request->companyurl,
                'company_logo' => $logoPath,
                'registration_type' => !empty($registrationTypes) ? json_encode($registrationTypes) : null,
                'registration_no' => !empty($registrationNumbers) ? json_encode($registrationNumbers) : null,
                'registration_attachment' => !empty($registrationAttachments) ? json_encode($registrationAttachments) : null,
                'status' => $request->status,
                'added_by' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ];

            // Add agreement and scope fields for tenant database if type is 'company'
            if ($request->agreement_type === 'company') {
                $tenantCompanyData['agreement_ref_no'] = $request->agreement_ref_no;
                $tenantCompanyData['agreement_name'] = $request->agreement_name;
                $tenantCompanyData['nature_of_agreement'] = $request->nature_of_agreement;
                $tenantCompanyData['mode_of_document'] = $request->mode_of_document;
                $tenantCompanyData['no_of_legalentity'] = $request->no_of_legalentity;
                $tenantCompanyData['agreement_date'] = $request->agreement_date;
                $tenantCompanyData['agreement_type'] = $request->agreement_type_dropdown;
                $tenantCompanyData['vertical'] = $request->vertical;
                $tenantCompanyData['effective_from'] = $request->effective_from;
                $tenantCompanyData['effective_to'] = $request->effective_to;
                $tenantCompanyData['renewal_due_on'] = $request->renewal_due_on;
                $tenantCompanyData['domain_name'] = $request->domain_name;
                $tenantCompanyData['type_of_organization'] = $request->type_of_organization;
                $tenantCompanyData['scope_state'] = $request->scope_state;
                $tenantCompanyData['act'] = $request->act;
            }

            // Insert into tenant database company table
            DB::connection('tenant')->table('company')->insert($tenantCompanyData);

            $statusMessage = $request->status === 'Draft' ? 'saved as draft' : 'created';
            return back()->with('success', "Company '{$companyName}' has been {$statusMessage} successfully!");
        } catch (\Throwable $e) {
            // Cleanup on error
            if (isset($companyId)) {
                try {
                    DB::table('companies')->where('company_id', $companyId)->delete();
                } catch (\Exception $ex) {
                    Log::error("Failed to delete company record: " . $ex->getMessage());
                }

                // Delete uploaded files
                if (isset($companyFolder) && file_exists($companyFolder)) {
                    $this->deleteDirectory($companyFolder);
                }
            }

            // Drop tenant database if created
            if (isset($tenantDbName)) {
                try {
                    $dbExists = DB::select("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?", [$tenantDbName]);
                    if (!empty($dbExists)) {
                        DB::statement("DROP DATABASE IF EXISTS `{$tenantDbName}`");
                    }
                } catch (\Exception $ex) {
                    Log::error("Failed to drop database {$tenantDbName}: " . $ex->getMessage());
                }
            }

            Log::error('Company creation failed: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);

            return back()->with('error', 'Failed to create company: ' . $e->getMessage())->withInput();
        }
    }

    /**
     * Recursively delete directory
     */
    private function deleteDirectory($dir)
    {
        if (!file_exists($dir)) {
            return true;
        }

        if (!is_dir($dir)) {
            return unlink($dir);
        }

        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }

            if (!$this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }

        return rmdir($dir);
    }


    //legalentity
    public function createLegalEntity()
    {
        $companies = DB::table('companies')->get();
        return view('createlegalentity', compact('companies'));
    }

    public function getCompany($company_id)
    {
        $company = DB::table('companies')->where('company_id', $company_id)->first();
        return response()->json($company);
    }

  public function legalEntityStore(Request $request)
{
    $request->validate([
        'company_id' => 'required|string|exists:companies,company_id',
        'type' => 'required|in:company,legal',
        'legalentity_name' => 'required|string|max:255',
        'legalentity_short_name' => 'required|string|max:100',
        'reference_no' => 'required|string|max:100',
        'state' => 'required|string|max:100',
        'city' => 'required|string|max:100',
        'pincode' => 'required|string|max:20',
        'contact_person' => 'required|string|max:150',
        'mobile_number' => 'required|string|max:20',
        'email' => 'required|email|max:150',
        'legalentity_logo' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
        'registration_type.*' => 'nullable|string|max:100',
        'registration_no.*' => 'nullable|string|max:150',
        'registration_attachment.*' => 'nullable|file|mimes:jpeg,png,jpg,pdf|max:5120',
        'status' => 'required|in:Draft,Saved',
    ]);

    $legalEntityId = null;
    $companyFolder = null;
    $legalFolder = null;

    try {
        // Fetch company from central database
        $company = DB::table('companies')->where('company_id', $request->company_id)->first();
        if (!$company) {
            throw new \Exception('Company not found');
        }

        $tenantDbName = $company->db_name;

        // Switch to tenant database
        config(['database.connections.tenant.database' => $tenantDbName]);
        DB::purge('tenant');
        DB::connection('tenant')->reconnect();

        // Generate legalentity_id
        $lastLegal = DB::connection('tenant')->table('legal_entity')
            ->where('company_id', $request->company_id)
            ->orderByDesc('id')
            ->first();

        $nextNumber = $lastLegal && preg_match('/LEGAL_(\d+)/', $lastLegal->legalentity_id ?? '', $matches)
            ? (int)$matches[1] + 1
            : 1;
        $legalEntityId = 'LEGAL_' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

        // Create folders
        $companyFolder = public_path("assets/company/{$request->company_id}");
        $legalFolder = $companyFolder . "/legal_entities/{$legalEntityId}";
        if (!file_exists($legalFolder)) {
            mkdir($legalFolder, 0755, true);
            mkdir($legalFolder . '/registrations', 0755, true);
        }

        // Handle logo upload
        $logoPath = null;
        if ($request->hasFile('legalentity_logo')) {
            $logoFile = $request->file('legalentity_logo');
            $logoName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $logoFile->getClientOriginalName());
            $logoFile->move($legalFolder, $logoName);
            $logoPath = "assets/company/{$request->company_id}/legal_entities/{$legalEntityId}/{$logoName}";
        }

        // Handle registration attachments
        $registrationTypes = [];
        $registrationNumbers = [];
        $registrationAttachments = [];

        if ($request->has('registration_type')) {
            foreach ($request->registration_type as $index => $type) {
                if (!empty($type)) {
                    $registrationTypes[] = $type;
                    $registrationNumbers[] = $request->registration_no[$index] ?? null;

                    $attachmentPath = null;
                    if ($request->hasFile("registration_attachment.{$index}")) {
                        $file = $request->file("registration_attachment.{$index}");
                        $fileName = time() . "_{$index}_" . preg_replace('/[^a-zA-Z0-9._-]/', '', $file->getClientOriginalName());
                        $file->move($legalFolder . '/registrations', $fileName);
                        $attachmentPath = "assets/company/{$request->company_id}/legal_entities/{$legalEntityId}/registrations/{$fileName}";
                    }
                    $registrationAttachments[] = $attachmentPath;
                }
            }
        }

        // Base data from request
        $legalData = [
            'company_id' => $request->company_id,
            'type' => $request->type,
            'legalentity_id' => $legalEntityId,
            'legalentity_name' => $request->legalentity_name,
            'legalentity_short_name' => $request->legalentity_short_name,
            'reference_no' => $request->reference_no,
            'address1' => $request->address1,
            'address2' => $request->address2,
            'state' => $request->state,
            'city' => $request->city,
            'pincode' => $request->pincode,
            'contact_person' => $request->contact_person,
            'mobile_number' => $request->mobile_number,
            'telephone_number' => $request->telephone_number,
            'email' => $request->email,
            'legalentity_url' => $request->legalentity_url,
            'legalentity_logo' => $logoPath,
            'registration_type' => !empty($registrationTypes) ? json_encode($registrationTypes) : null,
            'registration_no' => !empty($registrationNumbers) ? json_encode($registrationNumbers) : null,
            'registration_attachment' => !empty($registrationAttachments) ? json_encode($registrationAttachments) : null,
            'status' => $request->status,
            'added_by' => auth()->id() ?? null,
            'created_at' => now(),
            'updated_at' => now(),
        ];

        // === CRITICAL FIX: If type is 'company', copy agreement & scope from parent company ===
        if ($request->type === 'company') {
            $legalData = array_merge($legalData, [
                'agreement_ref_no' => $company->agreement_ref_no,
                'agreement_name' => $company->agreement_name,
                'nature_of_agreement' => $company->nature_of_agreement,
                'mode_of_document' => $company->mode_of_document,
                'no_of_legalentity' => $company->no_of_legalentity,
                'agreement_date' => $company->agreement_date,
                'agreement_type' => $company->agreement_type,
                'vertical' => $company->vertical,
                'effective_from' => $company->effective_from,
                'effective_to' => $company->effective_to,
                'renewal_due_on' => $company->renewal_due_on,
                'domain_name' => $company->domain_name,
                'type_of_organization' => $company->type_of_organization,
                'scope_state' => $company->scope_state,
                'act' => $company->act,
            ]);
        } else {
            // For 'legal' type → use submitted values (fields are enabled)
            $legalData = array_merge($legalData, [
                'agreement_ref_no' => $request->agreement_ref_no,
                'agreement_name' => $request->agreement_name,
                'nature_of_agreement' => $request->nature_of_agreement,
                'mode_of_document' => $request->mode_of_document,
                'no_of_legalentity' => $request->no_of_legalentity,
                'agreement_date' => $request->agreement_date,
                'agreement_type' => $request->agreement_type,
                'vertical' => $request->vertical,
                'effective_from' => $request->effective_from,
                'effective_to' => $request->effective_to,
                'renewal_due_on' => $request->renewal_due_on,
                'domain_name' => $request->domain_name,
                'type_of_organization' => $request->type_of_organization,
                'scope_state' => $request->scope_state,
                'act' => $request->act,
            ]);
        }

        // Insert into tenant's legal_entity table
        DB::connection('tenant')->table('legal_entity')->insert($legalData);

        $statusMessage = $request->status === 'Draft' ? 'saved as draft' : 'created';
        return back()->with('success', "Legal Entity '{$request->legalentity_name}' has been {$statusMessage} successfully!");

    } catch (\Throwable $e) {
        // Cleanup uploaded files on failure
        if (isset($legalFolder) && file_exists($legalFolder)) {
            $this->deleteDirectory($legalFolder);
        }

        Log::error('Legal entity creation failed: ' . $e->getMessage(), [
            'trace' => $e->getTraceAsString(),
            'request' => $request->all()
        ]);

        return back()->with('error', 'Failed to create legal entity: ' . $e->getMessage())->withInput();
    }
}
public function checkLimit($companyId)
{
    try {
        $central = DB::table('companies')
            ->where('company_id', $companyId)
            ->first();

        if (!$central) {
            return response()->json([
                'allowed' => false,
                'message' => 'Company not found.'
            ]);
        }

        $tenantDb = $central->db_name;

        // Switch to tenant
        config(['database.connections.tenant.database' => $tenantDb]);
        DB::purge('tenant');
        DB::connection('tenant')->reconnect();

        $max = (int) DB::connection('tenant')
            ->table('company')
            ->where('company_id', $companyId)
            ->value('no_of_legalentity');

        $current = DB::connection('tenant')
            ->table('legal_entity')
            ->where('company_id', $companyId)
            ->count();

        if ($current >= $max) {
            return response()->json([
                'allowed' => false,
                'message' => "Legal entity limit reached ({$current}/{$max}). Cannot create more."
            ]);
        }

        $remaining = $max - $current;
        $word = $remaining == 1 ? 'entity' : 'entities';

        return response()->json([
            'allowed' => true,
            'message' => "You can create {$remaining} more legal {$word}."
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'allowed' => false,
            'message' => 'Cannot check limit right now. Please try again.'
        ]);
    }
}
}
